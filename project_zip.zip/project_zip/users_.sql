-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:5500
-- Generation Time: Dec 12, 2017 at 04:16 PM
-- Server version: 5.5.45
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se266_brandon`
--

-- --------------------------------------------------------

--
-- Table structure for table `users_`
--

CREATE TABLE `users_` (
  `uname` varchar(50) NOT NULL,
  `pw` varchar(256) NOT NULL,
  `status` varchar(50) NOT NULL,
  `is_admin` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_`
--

INSERT INTO `users_` (`uname`, `pw`, `status`, `is_admin`) VALUES
('admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'active', 'admin'),
('c', '84a516841ba77a5b4648de2cd0dfcb30ea46dbb4', 'active', 'no'),
('brandonp98', 'e9d71f5ee7c92d6dc9e92ffdad17b8bd49418f98', 'active', 'admin'),
('jose', '5c2dd944dde9e08881bef0894fe7b22a5c9c4b06', 'active', 'no'),
('j', '5c2dd944dde9e08881bef0894fe7b22a5c9c4b06', 'active', 'no'),
('Brandon', '516b9783fca517eecbd1d064da2d165310b19759', 'active', 'admin'),
('joey', '56a580ad3befc663da709977ba17447ffa133c85', 'active', 'no'),
('Delio', 'e703908953979aba5049ec2e83f4e104282abe84', 'active', 'no');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
