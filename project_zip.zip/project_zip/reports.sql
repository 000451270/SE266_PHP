-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:5500
-- Generation Time: Dec 12, 2017 at 04:17 PM
-- Server version: 5.5.45
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se266_brandon`
--

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `game_title` varchar(256) NOT NULL,
  `platform` varchar(256) NOT NULL,
  `esrb_rating` varchar(256) NOT NULL,
  `severity` varchar(256) NOT NULL,
  `description` varchar(256) NOT NULL,
  `date_submitted` varchar(256) NOT NULL,
  `likes` varchar(256) NOT NULL,
  `dislikes` varchar(256) NOT NULL,
  `liked_by` varchar(256) NOT NULL,
  `disliked_by` varchar(256) NOT NULL,
  `sub_by` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `game_title`, `platform`, `esrb_rating`, `severity`, `description`, `date_submitted`, `likes`, `dislikes`, `liked_by`, `disliked_by`, `sub_by`) VALUES
(4, 'Call of Duty WWII', 'PS4', 'M', 'minor', 'Lost some progress', '07-12-2017 20:11:31', '3', '1', 'delio,joey,Brandon,', 'joey,', 'Brandon'),
(5, 'cod ww2', 'PS4', 'T', 'minor', 'ahhhhhh', '08-12-2017 17:37:55', '0', '0', '', '', 'joey'),
(6, 'Destiny 2', 'PS4', 'T', 'major', 'game crashing while spawning in crucible', '11-12-2017 18:42:20', '0', '0', '', '', 'delio');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
